require 'test_helper'

class UserPlaceTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
