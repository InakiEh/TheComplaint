require 'test_helper'

class UserLikeCommentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
