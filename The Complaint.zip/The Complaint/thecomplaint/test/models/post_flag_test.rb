require 'test_helper'

class PostFlagTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
