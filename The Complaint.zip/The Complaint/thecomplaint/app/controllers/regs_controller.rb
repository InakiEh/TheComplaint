class RegsController < ApplicationController

    def reg
    end
end
