class EditprofilesController < ApplicationController

    def editprofile
    end
end
