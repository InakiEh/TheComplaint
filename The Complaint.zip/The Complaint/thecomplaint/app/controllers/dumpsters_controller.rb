class DumpstersController < ApplicationController

    def dumpster
    end
end
