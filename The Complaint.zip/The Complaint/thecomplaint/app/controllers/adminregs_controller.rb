class AdminregsController < ApplicationController
    
  def adminreg
  end
  
end
