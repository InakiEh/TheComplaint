class UsersearchsController < ApplicationController
end
