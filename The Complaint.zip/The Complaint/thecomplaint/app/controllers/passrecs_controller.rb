class PassrecsController < ApplicationController

    def passrec
    end
end
