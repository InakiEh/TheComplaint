class SessionsController < ApplicationController
  def new
  end

  def create
    #recibe los datos de usuario y si coincide con la base de datos, 
    #se crea una nueva instancia de session
  end

  def destroy
  end
end
