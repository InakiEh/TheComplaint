class UserTag < ApplicationRecord
  belongs_to :comment_id
end
