class PostFlag < ApplicationRecord
end
