class UserPlace < ApplicationRecord
end
