class UserLikeComment < ApplicationRecord
end
