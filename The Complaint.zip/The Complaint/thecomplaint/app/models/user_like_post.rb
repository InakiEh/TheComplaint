class UserLikePost < ApplicationRecord
    belongs_to :post
end
