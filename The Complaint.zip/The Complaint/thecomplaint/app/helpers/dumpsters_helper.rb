module DumpstersHelper
end
