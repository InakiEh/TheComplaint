module AdminregsHelper
end
